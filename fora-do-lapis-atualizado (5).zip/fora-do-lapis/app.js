/*
========================================
FORA DO LÁPIS - SISTEMA DE AGENDAMENTO
JavaScript principal
========================================
*/

const DISCIPLINAS_PADRAO = ["Matemática", "Português", "Inglês", "Física"];

/* ---------- Storage helpers ---------- */

var DISP_PADRAO = {
    dias: [1, 2, 3, 4, 5],
    horarios: ["08:00", "10:00", "14:00", "16:00", "18:00"]
};

var DIAS_NOMES = { 0: "Dom", 1: "Seg", 2: "Ter", 3: "Qua", 4: "Qui", 5: "Sex", 6: "Sáb" };

function getProfessores() {
    const salvos = JSON.parse(localStorage.getItem("professores") || "[]");
    if (salvos.length === 0) {
        return [
            { id: 1, nome: "Gabriel Santos", email: "gabriel@email.com", disciplina: "Matemática", tipo: "professor", bio: "Especialista em álgebra e geometria.", bannerCor: 1, disponibilidade: { dias: [1,2,3,4,5], horarios: ["08:00","10:00","14:00","16:00","18:00"] } },
            { id: 2, nome: "Mariana Oliveira", email: "mariana@email.com", disciplina: "Português", tipo: "professor", bio: "Gramática, literatura e redação.", bannerCor: 2, disponibilidade: { dias: [1,2,3,4,5], horarios: ["09:00","11:00","14:00","16:00"] } },
            { id: 3, nome: "Lucas Almeida", email: "lucas@email.com", disciplina: "Inglês", tipo: "professor", bio: "Conversação e preparação para exames.", bannerCor: 3, disponibilidade: { dias: [1,3,5,6], horarios: ["10:00","14:00","16:00","18:00","19:00"] } }
        ];
    }
    return salvos;
}

function setProfessores(lista) {
    localStorage.setItem("professores", JSON.stringify(lista));
}

function getAlunos() {
    return JSON.parse(localStorage.getItem("alunos") || "[]");
}

function setAlunos(lista) {
    localStorage.setItem("alunos", JSON.stringify(lista));
}

function getAgendamentos() {
    return JSON.parse(localStorage.getItem("agendamentos") || "[]");
}

function setAgendamentos(lista) {
    localStorage.setItem("agendamentos", JSON.stringify(lista));
}

function getUsuarioLogado() {
    return JSON.parse(localStorage.getItem("usuarioLogado") || "null");
}

function setUsuarioLogado(usuario) {
    if (usuario) {
        localStorage.setItem("usuarioLogado", JSON.stringify(usuario));
    } else {
        localStorage.removeItem("usuarioLogado");
    }
}

/* ---------- Foto de perfil e anexos do professor ---------- */

function lerArquivoComoDataURL(file, maxBytes, callback) {
    if (!file) return;
    if (maxBytes && file.size > maxBytes) {
        mostrarToast("Arquivo muito grande. Máximo: " + Math.round(maxBytes / 1024) + " KB.");
        return;
    }
    var reader = new FileReader();
    reader.onload = function (e) {
        callback(e.target.result, file);
    };
    reader.onerror = function () {
        mostrarToast("Erro ao ler o arquivo.");
    };
    reader.readAsDataURL(file);
}

function aplicarFotoNoAvatar(avatarEl, usuario) {
    if (!avatarEl) return;
    if (usuario && usuario.foto) {
        avatarEl.classList.add("has-photo");
        avatarEl.innerHTML = '<img src="' + usuario.foto + '" alt="Foto de perfil">';
    } else {
        avatarEl.classList.remove("has-photo");
        avatarEl.innerHTML = "";
        avatarEl.textContent = ((usuario && usuario.nome) || "?").charAt(0).toUpperCase();
    }
}

function setupFotoPerfil(avatarEl, inputEl, onSave) {
    if (!avatarEl || !inputEl) return;
    avatarEl.style.cursor = "pointer";
    avatarEl.title = "Clique para alterar a foto";
    avatarEl.addEventListener("click", function () {
        inputEl.click();
    });
    inputEl.addEventListener("change", function () {
        var file = inputEl.files && inputEl.files[0];
        if (!file) return;
        if (!file.type || file.type.indexOf("image/") !== 0) {
            mostrarToast("Selecione uma imagem (JPG, PNG, etc.).");
            inputEl.value = "";
            return;
        }
        // Máx. ~400 KB para não estourar localStorage
        lerArquivoComoDataURL(file, 400 * 1024, function (dataUrl) {
            onSave(dataUrl);
            inputEl.value = "";
        });
    });
}

function getMateriaisProfessor(email) {
    var all = JSON.parse(localStorage.getItem("materiaisProfessor") || "{}");
    return all[email] || [];
}

function setMateriaisProfessor(email, lista) {
    var all = JSON.parse(localStorage.getItem("materiaisProfessor") || "{}");
    all[email] = lista;
    localStorage.setItem("materiaisProfessor", JSON.stringify(all));
}

/* ---------- Avaliações ---------- */

function getAvaliacoes(profEmail) {
    var all = JSON.parse(localStorage.getItem("avaliacoes") || "{}");
    return all[profEmail] || [];
}

function setAvaliacoes(profEmail, lista) {
    var all = JSON.parse(localStorage.getItem("avaliacoes") || "{}");
    all[profEmail] = lista;
    localStorage.setItem("avaliacoes", JSON.stringify(all));
}

function mediaAvaliacoes(profEmail) {
    var lista = getAvaliacoes(profEmail);
    if (!lista.length) return { media: 5.0, total: 0 };
    var soma = lista.reduce(function (s, a) { return s + Number(a.nota); }, 0);
    return { media: Math.round((soma / lista.length) * 10) / 10, total: lista.length };
}

function alunoJaAvaliou(profEmail, alunoEmail) {
    return getAvaliacoes(profEmail).some(function (a) { return a.alunoEmail === alunoEmail; });
}

function alunoTeveAulaCom(profEmail, alunoEmail) {
    var prof = getProfessores().find(function (p) { return p.email === profEmail; });
    if (!prof) return false;
    return getAgendamentos().some(function (a) {
        return isConfirmada(a) &&
            (a.email === alunoEmail) &&
            (a.professor === prof.nome || a.professorEmail === profEmail);
    });
}

/* ---------- Chat (no perfil do professor) ---------- */

function chatKey(profEmail, alunoEmail) {
    return String(profEmail).toLowerCase() + "|" + String(alunoEmail).toLowerCase();
}

function getChat(profEmail, alunoEmail) {
    var all = JSON.parse(localStorage.getItem("chats") || "{}");
    return all[chatKey(profEmail, alunoEmail)] || [];
}

function setChat(profEmail, alunoEmail, msgs) {
    var all = JSON.parse(localStorage.getItem("chats") || "{}");
    all[chatKey(profEmail, alunoEmail)] = msgs;
    localStorage.setItem("chats", JSON.stringify(all));
}

function enviarMensagemChat(profEmail, alunoEmail, deTipo, texto) {
    texto = (texto || "").trim();
    if (!texto) return;
    var msgs = getChat(profEmail, alunoEmail);
    msgs.push({
        de: deTipo, // 'aluno' | 'professor'
        texto: texto,
        data: new Date().toISOString()
    });
    setChat(profEmail, alunoEmail, msgs);
}

function listarConversasProfessor(profEmail) {
    var all = JSON.parse(localStorage.getItem("chats") || "{}");
    var prefix = String(profEmail).toLowerCase() + "|";
    var conversas = [];
    Object.keys(all).forEach(function (k) {
        if (k.indexOf(prefix) === 0) {
            var alunoEmail = k.slice(prefix.length);
            var msgs = all[k] || [];
            if (msgs.length) {
                conversas.push({
                    alunoEmail: alunoEmail,
                    msgs: msgs,
                    ultima: msgs[msgs.length - 1]
                });
            }
        }
    });
    // também incluir alunos com aula agendada (mesmo sem msg ainda)
    var prof = getProfessores().find(function (p) { return p.email === profEmail; });
    if (prof) {
        getAgendamentos().forEach(function (a) {
            if ((a.professor === prof.nome || a.professorEmail === profEmail) &&
                statusAgendamento(a) !== "recusada") {
                var exists = conversas.some(function (c) { return c.alunoEmail === a.email; });
                if (!exists && a.email) {
                    conversas.push({ alunoEmail: a.email, msgs: [], ultima: null, nomeAluno: a.nome });
                }
            }
        });
    }
    return conversas;
}

function getQueryParam(name) {
    var params = new URLSearchParams(window.location.search);
    return params.get(name);
}


/* ---------- Status de agendamento ---------- */

function statusAgendamento(a) {
    return a.status || "confirmada"; // dados antigos sem status = já confirmados
}

function isConfirmada(a) {
    return statusAgendamento(a) === "confirmada";
}

function isPendente(a) {
    return statusAgendamento(a) === "pendente";
}


/* ---------- Menu mobile ---------- */

function toggleMenu() {
    const menu = document.getElementById("menu");
    if (!menu) return;
    if (menu.style.display === "flex") {
        menu.style.display = "none";
    } else {
        menu.style.display = "flex";
        menu.style.flexDirection = "column";
        menu.style.position = "absolute";
        menu.style.top = "76px";
        menu.style.left = "0";
        menu.style.right = "0";
        menu.style.padding = "20px";
        menu.style.background = "white";
        menu.style.borderBottom = "1px solid #eee";
        menu.style.zIndex = "999";
    }
}

/* ---------- Modais ---------- */

function abrirLogin() {
    const el = document.getElementById("loginModal");
    if (el) el.classList.add("active");
}

/**
 * Login direto com conta Google (simulado no front-end).
 * Em produção, integraria com Google Identity Services / OAuth.
 * Aqui: pede o tipo de conta e cria/loga um usuário vinculado ao Google.
 */
function loginComGoogle() {
    var tipo = window.prompt(
        "Entrar com Google — escolha o tipo de conta:\n\n" +
        "Digite 'aluno' ou 'professor'",
        "aluno"
    );
    if (!tipo) return;
    tipo = tipo.trim().toLowerCase();
    if (tipo !== "aluno" && tipo !== "professor") {
        mostrarToast("Tipo inválido. Use 'aluno' ou 'professor'.");
        return;
    }

    var nome = window.prompt("Nome da sua conta Google:", "Usuário Google");
    if (!nome || !nome.trim()) {
        mostrarToast("Nome é obrigatório.");
        return;
    }
    nome = nome.trim();

    // E-mail simulado no padrão Google
    var emailBase = nome.toLowerCase()
        .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
        .replace(/[^a-z0-9]+/g, ".")
        .replace(/^\.+|\.+$/g, "") || "usuario";
    var email = emailBase + "@gmail.com";

    var professores = getProfessores();
    var alunos = getAlunos();
    var existente = professores.find(function (p) { return p.email === email; }) ||
        alunos.find(function (a) { return a.email === email; });

    if (existente) {
        setUsuarioLogado({
            id: existente.id,
            nome: existente.nome,
            email: existente.email,
            tipo: existente.tipo,
            disciplina: existente.disciplina || undefined,
            bio: existente.bio || "",
            foto: existente.foto || undefined,
            loginGoogle: true
        });
        atualizarUIUsuario();
        mostrarToast("Login com Google realizado! Olá, " + existente.nome);
        fecharModal("loginModal");
        return;
    }

    // Cria nova conta vinculada ao Google
    var novo = {
        id: Date.now(),
        nome: nome,
        email: email,
        senha: "google-oauth",
        tipo: tipo,
        bio: "",
        loginGoogle: true
    };

    if (tipo === "professor") {
        var disc = window.prompt("Disciplina que você ensina:", "Matemática");
        novo.disciplina = (disc && disc.trim()) || "Geral";
        var listaP = getProfessores().slice();
        listaP.push(novo);
        localStorage.setItem("professores", JSON.stringify(listaP));
    } else {
        var listaA = getAlunos().slice();
        listaA.push(novo);
        localStorage.setItem("alunos", JSON.stringify(listaA));
    }

    setUsuarioLogado({
        id: novo.id,
        nome: novo.nome,
        email: novo.email,
        tipo: novo.tipo,
        disciplina: novo.disciplina || undefined,
        bio: "",
        loginGoogle: true
    });
    atualizarUIUsuario();
    mostrarToast("Conta Google criada e login realizado! Olá, " + nome);
    fecharModal("loginModal");
}

function fecharModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove("active");
}

function abrirTipoCadastro() {
    const el = document.getElementById("tipoCadastroModal");
    if (el) el.classList.add("active");
}

function escolherTipoCadastro(tipo) {
    fecharModal("tipoCadastroModal");
    abrirCadastro(tipo);
}

function abrirCadastro(tipo) {
    const modal = document.getElementById("registerModal");
    if (!modal) return;

    const titulo = document.getElementById("registerTitle");
    const desc = document.getElementById("registerDesc");
    const disciplinaGroup = document.getElementById("disciplinaGroup");
    const tipoInput = document.getElementById("registerTipo");
    const customGroup = document.getElementById("disciplinaCustomGroup");

    if (tipo === "professor") {
        if (titulo) titulo.textContent = "Cadastro de Professor";
        if (desc) desc.textContent = "Crie sua conta e defina a disciplina que você ensina.";
        if (disciplinaGroup) disciplinaGroup.style.display = "flex";
        const sel = document.getElementById("registerDisciplina");
        if (sel) sel.required = true;
        if (tipoInput) tipoInput.value = "professor";
    } else {
        if (titulo) titulo.textContent = "Cadastro de Aluno";
        if (desc) desc.textContent = "Crie sua conta para começar a agendar aulas.";
        if (disciplinaGroup) disciplinaGroup.style.display = "none";
        const sel = document.getElementById("registerDisciplina");
        if (sel) sel.required = false;
        if (customGroup) customGroup.style.display = "none";
        if (tipoInput) tipoInput.value = "aluno";
    }

    modal.classList.add("active");
}

function trocarParaCadastro() {
    fecharModal("loginModal");
    abrirTipoCadastro();
}

function trocarParaLogin() {
    fecharModal("registerModal");
    abrirLogin();
}

function onDisciplinaChange() {
    const select = document.getElementById("registerDisciplina");
    const customGroup = document.getElementById("disciplinaCustomGroup");
    const customInput = document.getElementById("registerDisciplinaCustom");
    if (!select || !customGroup) return;

    if (select.value === "__outra__") {
        customGroup.style.display = "flex";
        if (customInput) customInput.required = true;
    } else {
        customGroup.style.display = "none";
        if (customInput) customInput.required = false;
    }
}

/* ---------- Navegação ---------- */

function irParaAgendamento() {
    const el = document.getElementById("agendar");
    if (el) el.scrollIntoView({ behavior: "smooth" });
}

function selecionarDisciplina(disciplina) {
    const select = document.getElementById("discipline");
    if (select) {
        select.value = disciplina;
        atualizarProfessoresPorDisciplina();
    }
    irParaAgendamento();
}

function selecionarProfessor(professor) {
    const select = document.getElementById("teacher");
    const discSelect = document.getElementById("discipline");
    const prof = getProfessores().find(function (p) { return p.nome === professor; });
    if (prof && discSelect) {
        discSelect.value = prof.disciplina;
        atualizarSelectProfessores();
    }
    if (select) select.value = professor;
    atualizarHorariosDisponiveis();
    irParaAgendamento();
}

/* ---------- Toast ---------- */

function mostrarToast(mensagem) {
    const toast = document.getElementById("toast");
    const message = document.getElementById("toastMessage");
    if (!toast || !message) return;
    message.textContent = mensagem;
    toast.classList.add("active");
    setTimeout(function () {
        toast.classList.remove("active");
    }, 3500);
}

/* ---------- Selects ---------- */

function atualizarSelectProfessores() {
    const select = document.getElementById("teacher");
    if (!select) return;

    const disciplina = (document.getElementById("discipline") || {}).value || "";
    const professores = getProfessores();

    select.innerHTML = '<option value="">Selecione um professor</option>';

    const filtrados = disciplina
        ? professores.filter(function (p) { return p.disciplina === disciplina; })
        : professores;

    filtrados.forEach(function (p) {
        const opt = document.createElement("option");
        opt.value = p.nome;
        opt.textContent = p.nome + " (" + p.disciplina + ")";
        select.appendChild(opt);
    });
}

function atualizarProfessoresPorDisciplina() {
    atualizarSelectProfessores();
}

function atualizarSelectDisciplinas() {
    const select = document.getElementById("discipline");
    if (!select) return;

    const professores = getProfessores();
    const set = {};
    DISCIPLINAS_PADRAO.forEach(function (d) { set[d] = true; });
    professores.forEach(function (p) {
        if (p.disciplina) set[p.disciplina] = true;
    });

    const disciplinas = Object.keys(set).sort();
    const valorAtual = select.value;

    select.innerHTML = '<option value="">Selecione uma disciplina</option>';
    disciplinas.forEach(function (d) {
        const opt = document.createElement("option");
        opt.value = d;
        opt.textContent = d;
        select.appendChild(opt);
    });
    if (valorAtual) select.value = valorAtual;
}

/* ---------- Lista de professores (home) ---------- */

function renderizarProfessores() {
    const container = document.getElementById("teachersList");
    if (!container) return;

    const professores = getProfessores();
    const cores = ["purple-bg", "blue-bg", "green-bg", "orange-bg"];

    container.innerHTML = "";

    professores.forEach(function (p, i) {
        const cor = cores[i % cores.length];
        const card = document.createElement("div");
        card.className = "teacher-card";
        const nomeEsc = String(p.nome).replace(/'/g, "\\'");
        const av = mediaAvaliacoes(p.email);
        const estrelas = "★".repeat(Math.round(av.media)) + "☆".repeat(5 - Math.round(av.media));
        const disp = p.disponibilidade || DISP_PADRAO;
        const diasChips = (disp.dias || []).slice(0, 5).map(function (d) {
            return '<span class="chip">' + (DIAS_NOMES[d] || d) + '</span>';
        }).join("");
        var imgStyle = "";
        var imgContent = p.foto
            ? '<img src="' + p.foto + '" alt="' + escapeHtml(p.nome) + '">'
            : '<i class="fa-solid fa-user"></i>';
        if (p.bannerImg) {
            imgStyle = ' style="background-image:url(' + p.bannerImg + ');background-size:cover;background-position:center;"';
            imgContent = '<div class="teacher-banner-overlay"></div>' + (p.foto ? '<img src="' + p.foto + '" alt="' + escapeHtml(p.nome) + '" style="width:72px;height:72px;border-radius:50%;object-fit:cover;border:3px solid white;position:relative;z-index:1;">' : '<i class="fa-solid fa-user" style="position:relative;z-index:1;"></i>');
        } else if (p.bannerCor) {
            imgStyle = "";
        }
        var bgClass = p.bannerImg ? "" : (p.bannerCor ? "banner-preset-" + p.bannerCor : cor);
        card.innerHTML =
            '<div class="teacher-image ' + bgClass + '"' + imgStyle + '>' + imgContent + '</div>' +
            '<div class="teacher-info">' +
            "<h3>" + escapeHtml(p.nome) + "</h3>" +
            "<span>" + escapeHtml(p.disciplina || "") + "</span>" +
            (diasChips ? '<div class="teacher-disponibilidade">' + diasChips + '</div>' : '') +
            '<div class="rating">' + estrelas + ' <small>' + av.media.toFixed(1) +
            (av.total ? ' (' + av.total + ')' : '') + '</small></div>' +
            '<div class="teacher-actions">' +
            '<a href="perfil-professor.html?email=' + encodeURIComponent(p.email) + '" class="teacher-button btn-ver-perfil">Ver perfil</a>' +
            '<button type="button" onclick="selecionarProfessor(\'' + nomeEsc + '\')" class="teacher-button">Agendar</button>' +
            '</div>' +
            "</div>";
        container.appendChild(card);
    });
}

/* ---------- Calendário dinâmico ---------- */

var mesAtual = new Date().getMonth();
var anoAtual = new Date().getFullYear();

var NOMES_MES = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
];

function formatarDataISO(d) {
    var y = d.getFullYear();
    var m = String(d.getMonth() + 1).padStart(2, "0");
    var day = String(d.getDate()).padStart(2, "0");
    return y + "-" + m + "-" + day;
}

function renderizarCalendario() {
    var mesLabel = document.getElementById("calendarMonth");
    var daysContainer = document.getElementById("calendarDays");
    var weekContainer = document.getElementById("calendarWeek");
    if (!mesLabel || !daysContainer) return;

    mesLabel.textContent = NOMES_MES[mesAtual] + " " + anoAtual;

    if (weekContainer) {
        weekContainer.innerHTML =
            "<span>SEG</span><span>TER</span><span>QUA</span><span>QUI</span><span>SEX</span><span>SAB</span><span>DOM</span>";
    }

    var totalDias = new Date(anoAtual, mesAtual + 1, 0).getDate();
    // getDay(): 0=Dom, 1=Seg, ..., 6=Sáb → converter para índice com segunda-feira = 0
    var primeiroDiaSemana = new Date(anoAtual, mesAtual, 1).getDay();
    var offsetInicio = primeiroDiaSemana === 0 ? 6 : primeiroDiaSemana - 1;

    var agendamentos = getAgendamentos();
    var usuario = getUsuarioLogado();
    // Só marca no calendário as aulas do usuário logado (aluno: suas confirmadas; professor: confirmadas com ele)
    if (usuario) {
        if (usuario.tipo === "aluno") {
            agendamentos = agendamentos.filter(function (a) {
                return isConfirmada(a) && (a.email === usuario.email || a.nome === usuario.nome);
            });
        } else if (usuario.tipo === "professor") {
            agendamentos = agendamentos.filter(function (a) {
                return isConfirmada(a) && a.professor === usuario.nome;
            });
        }
    } else {
        // Sem login: não marca aulas de ninguém (privacidade)
        agendamentos = [];
    }
    var diasComAula = {};

    agendamentos.forEach(function (a) {
        var parts = a.data.split("-").map(Number);
        var y = parts[0], m = parts[1], d = parts[2];
        if (y === anoAtual && m - 1 === mesAtual) {
            if (!diasComAula[d]) diasComAula[d] = [];
            diasComAula[d].push(a);
        }
    });

    daysContainer.innerHTML = "";
    var hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    var hojeStr = formatarDataISO(hoje);

    // Células vazias antes do dia 1 (para alinhar com o dia da semana)
    for (var i = 0; i < offsetInicio; i++) {
        var empty = document.createElement("span");
        empty.className = "empty";
        empty.innerHTML = "&nbsp;";
        daysContainer.appendChild(empty);
    }

    // Todos os dias do mês (28/29/30/31)
    for (var dia = 1; dia <= totalDias; dia++) {
        var span = document.createElement("span");
        span.textContent = dia;
        var dataObj = new Date(anoAtual, mesAtual, dia);
        var dataStr = formatarDataISO(dataObj);
        var ds = dataObj.getDay(); // 0=Dom, 6=Sáb

        if (ds === 0 || ds === 6) {
            span.classList.add("weekend");
        }

        if (diasComAula[dia]) {
            span.classList.add("has-booking");
            span.title = diasComAula[dia]
                .map(function (a) { return a.disciplina + " " + a.horario; })
                .join(", ");
        }
        if (dataStr === hojeStr) span.classList.add("active");

        span.addEventListener("click", function (dataStrCapturada) {
            return function () {
                var spans = document.querySelectorAll("#calendarDays span:not(.empty)");
                for (var j = 0; j < spans.length; j++) spans[j].classList.remove("active");
                this.classList.add("active");
                mostrarProximoAgendamento(dataStrCapturada);
            };
        }(dataStr));

        daysContainer.appendChild(span);
    }

    mostrarProximoAgendamento();
}

function mostrarProximoAgendamento(dataFiltro) {
    var appointmentEl = document.getElementById("nextAppointment");
    var headerTitle = document.getElementById("dashboardSubject");
    var headerSmall = document.getElementById("dashboardLabel");
    if (!appointmentEl) return;

    var agora = new Date();
    var usuario = getUsuarioLogado();
    var base = getAgendamentos().filter(function (a) {
        if (!isConfirmada(a)) return false;
        if (!usuario) return false;
        if (usuario.tipo === "aluno") {
            return a.email === usuario.email || a.nome === usuario.nome;
        }
        if (usuario.tipo === "professor") {
            return a.professor === usuario.nome;
        }
        return false;
    });
    var lista = base
        .map(function (a) {
            return Object.assign({}, a, {
                datetime: new Date(a.data + "T" + a.horario + ":00")
            });
        })
        .filter(function (a) { return a.datetime >= agora; })
        .sort(function (a, b) { return a.datetime - b.datetime; });

    if (dataFiltro) {
        lista = lista.filter(function (a) { return a.data === dataFiltro; });
    }

    if (lista.length === 0) {
        if (headerSmall) headerSmall.textContent = "Próxima aula";
        if (headerTitle) headerTitle.textContent = "Nenhuma";
        appointmentEl.innerHTML =
            '<div class="appointment-icon"><i class="fa-solid fa-calendar"></i></div>' +
            "<div><strong>Sem agendamentos</strong><small>Agende sua próxima aula</small></div>" +
            "<strong>--</strong>";
        return;
    }

    var prox = lista[0];
    if (headerSmall) headerSmall.textContent = "Próxima aula";
    if (headerTitle) headerTitle.textContent = prox.disciplina;

    appointmentEl.innerHTML =
        '<div class="appointment-icon"><i class="fa-solid fa-calculator"></i></div>' +
        "<div><strong>" + prox.disciplina + "</strong><small>Prof. " + prox.professor + "</small></div>" +
        "<strong>" + prox.horario + "</strong>";
}

var ANO_MIN = new Date().getFullYear() - 1;
var ANO_MAX = new Date().getFullYear() + 1;

function mudarMes(delta) {
    mesAtual += delta;
    if (mesAtual > 11) {
        mesAtual = 0;
        anoAtual++;
    } else if (mesAtual < 0) {
        mesAtual = 11;
        anoAtual--;
    }
    // Limitação de ano: só permite ano atual ± 1
    if (anoAtual > ANO_MAX) {
        anoAtual = ANO_MAX;
        mesAtual = 11;
        mostrarToast("Não é possível avançar além de " + ANO_MAX + ".");
    } else if (anoAtual < ANO_MIN) {
        anoAtual = ANO_MIN;
        mesAtual = 0;
        mostrarToast("Não é possível voltar antes de " + ANO_MIN + ".");
    }
    renderizarCalendario();
}

/* ---------- UI usuário logado ---------- */

function atualizarUIUsuario() {
    var usuario = getUsuarioLogado();
    var navButtons = document.querySelector(".nav-buttons");
    if (!navButtons) return;

    // Atualiza menu principal: aba de solicitações só para professor logado
    var menu = document.getElementById("menu");
    if (menu) {
        var linksBase =
            '<a href="index.html">Início</a>' +
            '<a href="index.html#disciplinas">Disciplinas</a>' +
            '<a href="index.html#professores">Professores</a>' +
            '<a href="index.html#agendar">Agendar</a>';
        if (usuario && usuario.tipo === "professor") {
            linksBase +=
                '<a href="perfil-professor.html#secao-solicitacoes" class="nav-solicitacoes">' +
                '<i class="fa-solid fa-inbox"></i> Solicitações</a>';
        } else if (usuario && usuario.tipo === "aluno") {
            linksBase +=
                '<a href="perfil-aluno.html" class="nav-minhas-aulas">' +
                '<i class="fa-solid fa-calendar-check"></i> Minhas aulas</a>';
        }
        // Na home os hrefs originais são âncoras; preserva se estiver na home
        var page = document.body.getAttribute("data-page") || "";
        if (page === "home") {
            linksBase =
                '<a href="#inicio">Início</a>' +
                '<a href="#disciplinas">Disciplinas</a>' +
                '<a href="#professores">Professores</a>' +
                '<a href="#agendar">Agendar</a>';
            if (usuario && usuario.tipo === "professor") {
                linksBase +=
                    '<a href="perfil-professor.html#secao-solicitacoes" class="nav-solicitacoes">' +
                    '<i class="fa-solid fa-inbox"></i> Solicitações</a>';
            } else if (usuario && usuario.tipo === "aluno") {
                linksBase +=
                    '<a href="perfil-aluno.html" class="nav-minhas-aulas">' +
                    '<i class="fa-solid fa-calendar-check"></i> Minhas aulas</a>';
            }
        }
        menu.innerHTML = linksBase;
    }

    if (usuario) {
        var perfilHref = usuario.tipo === "professor" ? "perfil-professor.html" : "perfil-aluno.html";
        var tipoLabel = usuario.tipo === "professor" ? ' <small class="role-tag">(Prof.)</small>' : "";
        var extraBtn = "";
        if (usuario.tipo === "professor") {
            extraBtn =
                '<a href="perfil-professor.html#secao-solicitacoes" class="btn-outline btn-sm btn-solicitacoes">' +
                '<i class="fa-solid fa-inbox"></i> Solicitações</a>';
        } else {
            extraBtn =
                '<a href="perfil-aluno.html" class="btn-outline btn-sm">' +
                '<i class="fa-solid fa-calendar-check"></i> Minhas aulas</a>';
        }
        navButtons.innerHTML =
            '<a href="' + perfilHref + '" class="user-greeting">' +
            "Olá, <strong>" + usuario.nome.split(" ")[0] + "</strong>" + tipoLabel +
            "</a>" +
            extraBtn +
            '<a href="' + perfilHref + '" class="btn-outline btn-sm">Meu perfil</a>' +
            '<button type="button" class="btn-outline" onclick="logout()">Sair</button>';

        // Prefill formulário de agendamento se for aluno
        if (usuario.tipo === "aluno") {
            var sn = document.getElementById("studentName");
            var se = document.getElementById("studentEmail");
            if (sn && !sn.value) sn.value = usuario.nome;
            if (se && !se.value) se.value = usuario.email;
        }
    } else {
        navButtons.innerHTML =
            '<button type="button" class="btn-outline" onclick="abrirLogin()">Entrar</button>' +
            '<button type="button" class="btn-primary" onclick="abrirTipoCadastro()">Criar conta</button>';
    }
}

function logout() {
    setUsuarioLogado(null);
    atualizarUIUsuario();
    mostrarToast("Você saiu da conta.");
    // Se estiver em página de perfil, redireciona
    if (window.location.pathname.indexOf("perfil-") !== -1) {
        window.location.href = "index.html";
    }
}

function exigirLogin(tiposPermitidos) {
    var usuario = getUsuarioLogado();
    if (!usuario) {
        window.location.href = "index.html";
        return null;
    }
    if (tiposPermitidos && tiposPermitidos.indexOf(usuario.tipo) === -1) {
        var dest = usuario.tipo === "professor" ? "perfil-professor.html" : "perfil-aluno.html";
        window.location.href = dest;
        return null;
    }
    return usuario;
}

/* ---------- Eventos de formulários (home) ---------- */

function initHomeForms() {
    var bookingForm = document.getElementById("bookingForm");
    if (bookingForm) {
        var teacherSel = document.getElementById("teacher");
        var dateInput = document.getElementById("date");
        if (teacherSel) teacherSel.addEventListener("change", atualizarHorariosDisponiveis);
        if (dateInput) dateInput.addEventListener("change", atualizarHorariosDisponiveis);

        bookingForm.addEventListener("submit", function (event) {
            event.preventDefault();

            var usuario = getUsuarioLogado();
            if (!usuario) {
                mostrarToast("Faça login como aluno para solicitar uma aula.");
                abrirLogin();
                return;
            }
            if (usuario.tipo !== "aluno") {
                mostrarToast("Somente alunos podem solicitar agendamento.");
                return;
            }

            var disciplina = document.getElementById("discipline").value;
            var professor = document.getElementById("teacher").value;
            var data = document.getElementById("date").value;
            var horario = document.getElementById("time").value;
            var anoEscolaridade = document.getElementById("studentYear") ? document.getElementById("studentYear").value : "";
            var nome = (document.getElementById("studentName").value || "").trim() || usuario.nome;
            var email = (document.getElementById("studentEmail").value || "").trim() || usuario.email;

            if (!disciplina || !professor || !data || !horario || !nome || !email || !anoEscolaridade) {
                mostrarToast("Preencha todos os campos.");
                return;
            }

            var anoEscolhido = parseInt(data.split("-")[0], 10);
            if (anoEscolhido < ANO_MIN || anoEscolhido > ANO_MAX) {
                mostrarToast("Só é possível agendar entre " + ANO_MIN + " e " + ANO_MAX + ".");
                return;
            }

            // Validar disponibilidade do professor
            var disp = getDisponibilidadeProfessor(professor);
            var partes = data.split("-").map(Number);
            var diaSemana = new Date(partes[0], partes[1] - 1, partes[2]).getDay();
            if ((disp.dias || []).indexOf(diaSemana) === -1) {
                mostrarToast("Este professor não está disponível neste dia da semana.");
                return;
            }
            if ((disp.horarios || []).indexOf(horario) === -1) {
                mostrarToast("Este horário não está na disponibilidade do professor.");
                return;
            }

            var agendamentos = getAgendamentos();
            // Conflito só com confirmadas ou pendentes do mesmo professor/horário
            var conflito = agendamentos.find(function (a) {
                return a.professor === professor && a.data === data && a.horario === horario
                    && statusAgendamento(a) !== "recusada";
            });
            if (conflito) {
                mostrarToast("Horário já ocupado ou com solicitação pendente para este professor.");
                return;
            }

            var profObj = getProfessores().find(function (p) { return p.nome === professor; });
            agendamentos.push({
                id: Date.now(),
                disciplina: disciplina,
                professor: professor,
                professorEmail: profObj ? profObj.email : null,
                data: data,
                horario: horario,
                nome: nome,
                email: email,
                anoEscolaridade: anoEscolaridade,
                status: "pendente"
            });
            setAgendamentos(agendamentos);

            mostrarToast("Solicitação enviada! Aguarde a confirmação do professor.");
            bookingForm.reset();
            // mantém nome/email do aluno logado
            document.getElementById("studentName").value = usuario.nome;
            document.getElementById("studentEmail").value = usuario.email;
            renderizarCalendario();
            atualizarSelectProfessores();
        });
    }

    var loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault();
            var email = document.getElementById("loginEmail").value.trim();
            var senha = document.getElementById("loginPassword").value;

            if (!email || !senha) {
                mostrarToast("Preencha e-mail e senha.");
                return;
            }

            var professores = getProfessores();
            var alunos = getAlunos();
            var usuario = professores.find(function (p) { return p.email === email; });
            if (!usuario) {
                usuario = alunos.find(function (a) { return a.email === email; });
            }

            if (!usuario) {
                mostrarToast("Conta não encontrada. Crie uma conta primeiro.");
                return;
            }

            // Demo: não valida senha rigidamente
            setUsuarioLogado({
                id: usuario.id,
                nome: usuario.nome,
                email: usuario.email,
                tipo: usuario.tipo,
                disciplina: usuario.disciplina || undefined,
                bio: usuario.bio || ""
            });
            atualizarUIUsuario();
            mostrarToast("Login realizado! Olá, " + usuario.nome);
            fecharModal("loginModal");
            loginForm.reset();
        });
    }

    var registerForm = document.getElementById("registerForm");
    if (registerForm) {
        registerForm.addEventListener("submit", function (event) {
            event.preventDefault();

            var nome = document.getElementById("registerName").value.trim();
            var email = document.getElementById("registerEmail").value.trim();
            var senha = document.getElementById("registerPassword").value;
            var tipo = document.getElementById("registerTipo").value;
            var disciplinaSelect = document.getElementById("registerDisciplina");
            var disciplinaCustom = document.getElementById("registerDisciplinaCustom");

            if (!nome || !email || !senha) {
                mostrarToast("Preencha todos os campos obrigatórios.");
                return;
            }

            var disciplina = "";
            if (tipo === "professor") {
                disciplina = disciplinaSelect ? disciplinaSelect.value : "";
                if (disciplina === "__outra__") {
                    disciplina = disciplinaCustom ? disciplinaCustom.value.trim() : "";
                }
                if (!disciplina) {
                    mostrarToast("Selecione ou digite a disciplina.");
                    return;
                }
            }

            var professores = getProfessores();
            var alunos = getAlunos();
            var emails = professores.map(function (p) { return p.email; })
                .concat(alunos.map(function (a) { return a.email; }));

            if (emails.indexOf(email) !== -1) {
                mostrarToast("Este e-mail já está cadastrado.");
                return;
            }

            var novoId = Date.now();

            if (tipo === "professor") {
                var listaP = JSON.parse(localStorage.getItem("professores") || "[]");
                if (listaP.length === 0) {
                    listaP = getProfessores().slice();
                }
                var novoP = {
                    id: novoId,
                    nome: nome,
                    email: email,
                    disciplina: disciplina,
                    tipo: "professor",
                    bio: "",
                    senha: senha,
                    bannerCor: 1,
                    disponibilidade: { dias: [1, 2, 3, 4, 5], horarios: ["08:00", "10:00", "14:00", "16:00", "18:00"] }
                };
                listaP.push(novoP);
                setProfessores(listaP);
                setUsuarioLogado({
                    id: novoId,
                    nome: nome,
                    email: email,
                    tipo: "professor",
                    disciplina: disciplina,
                    bio: "",
                    bannerCor: 1,
                    disponibilidade: novoP.disponibilidade
                });
                mostrarToast("Conta de professor criada!");
            } else {
                var listaA = getAlunos();
                var novoA = {
                    id: novoId,
                    nome: nome,
                    email: email,
                    tipo: "aluno",
                    senha: senha
                };
                listaA.push(novoA);
                setAlunos(listaA);
                setUsuarioLogado({
                    id: novoId,
                    nome: nome,
                    email: email,
                    tipo: "aluno"
                });
                mostrarToast("Conta de aluno criada!");
            }

            fecharModal("registerModal");
            registerForm.reset();
            var customG = document.getElementById("disciplinaCustomGroup");
            if (customG) customG.style.display = "none";
            atualizarUIUsuario();
            renderizarProfessores();
            atualizarSelectProfessores();
            atualizarSelectDisciplinas();
        });
    }

    var discSelect = document.getElementById("discipline");
    if (discSelect) {
        discSelect.addEventListener("change", atualizarProfessoresPorDisciplina);
    }

    var dateInput = document.getElementById("date");
    if (dateInput) {
        dateInput.min = new Date().toISOString().split("T")[0];
        // Máximo: 31 de dezembro do próximo ano
        dateInput.max = ANO_MAX + "-12-31";
    }

    document.querySelectorAll(".modal").forEach(function (modal) {
        modal.addEventListener("click", function (event) {
            if (event.target === modal) modal.classList.remove("active");
        });
    });
}

/* ---------- Página de perfil do ALUNO ---------- */

function initPerfilAluno() {
    atualizarUIUsuario();

    var logado = getUsuarioLogado();
    var emailParam = getQueryParam("email");
    var alunos = getAlunos();
    var perfilAluno = null;
    var isDono = false;

    if (emailParam) {
        perfilAluno = alunos.find(function (a) {
            return a.email.toLowerCase() === emailParam.toLowerCase();
        });
        // também pode estar só no agendamento (nome/email)
        if (!perfilAluno) {
            var ag = getAgendamentos().find(function (a) {
                return a.email && a.email.toLowerCase() === emailParam.toLowerCase();
            });
            if (ag) {
                perfilAluno = { nome: ag.nome, email: ag.email, tipo: "aluno" };
            }
        }
        if (!perfilAluno) {
            mostrarToast("Aluno não encontrado.");
            setTimeout(function () { window.location.href = "index.html"; }, 1200);
            return;
        }
        isDono = !!(logado && logado.tipo === "aluno" &&
            logado.email.toLowerCase() === perfilAluno.email.toLowerCase());
        // professor pode ver; outros alunos também se souberem o link
        if (!logado) {
            window.location.href = "index.html";
            return;
        }
    } else {
        var usuario = exigirLogin(["aluno"]);
        if (!usuario) return;
        perfilAluno = alunos.find(function (a) { return a.email === usuario.email; }) || usuario;
        isDono = true;
        if (perfilAluno.foto) usuario.foto = perfilAluno.foto;
        if (perfilAluno.nome) usuario.nome = perfilAluno.nome;
        setUsuarioLogado(usuario);
    }

    var nomeEl = document.getElementById("perfilNome");
    var emailEl = document.getElementById("perfilEmail");
    var avatarEl = document.getElementById("perfilAvatarLetter");
    var totalEl = document.getElementById("statTotal");
    var proximasEl = document.getElementById("statProximas");
    var listaEl = document.getElementById("minhasAulas");
    var btnEditar = document.querySelector(".perfil-header .btn-primary");
    var linkAgendar = document.querySelector(".link-card");

    if (nomeEl) nomeEl.textContent = perfilAluno.nome;
    if (emailEl) emailEl.textContent = perfilAluno.email;
    aplicarFotoNoAvatar(avatarEl, perfilAluno);

    if (!isDono) {
        if (btnEditar) btnEditar.style.display = "none";
        if (linkAgendar) linkAgendar.style.display = "none";
        var fotoBtn = document.querySelector(".btn-change-photo");
        if (fotoBtn) fotoBtn.style.display = "none";
        var fotoHint = document.querySelector(".perfil-foto-hint");
        if (fotoHint) fotoHint.style.display = "none";
        if (avatarEl) {
            avatarEl.style.cursor = "default";
            avatarEl.title = "";
        }
    } else {
        var fotoInput = document.getElementById("fotoInputAluno");
        setupFotoPerfil(avatarEl, fotoInput, function (dataUrl) {
            var lista = getAlunos();
            var idx = lista.findIndex(function (a) { return a.email === perfilAluno.email; });
            if (idx !== -1) {
                lista[idx].foto = dataUrl;
                setAlunos(lista);
            }
            perfilAluno.foto = dataUrl;
            if (logado) {
                logado.foto = dataUrl;
                setUsuarioLogado(logado);
            }
            aplicarFotoNoAvatar(avatarEl, perfilAluno);
            mostrarToast("Foto de perfil atualizada!");
        });
    }

    var todos = getAgendamentos().filter(function (a) {
        return (a.email === perfilAluno.email || a.nome === perfilAluno.nome) &&
            statusAgendamento(a) !== "recusada";
    });

    var agora = new Date();
    var futuros = todos.filter(function (a) {
        return new Date(a.data + "T" + a.horario + ":00") >= agora;
    }).sort(function (a, b) {
        return new Date(a.data + "T" + a.horario) - new Date(b.data + "T" + b.horario);
    });

    var confirmadas = todos.filter(isConfirmada);
    var confirmadasFuturas = futuros.filter(isConfirmada);

    if (totalEl) totalEl.textContent = String(confirmadas.length);
    if (proximasEl) proximasEl.textContent = String(confirmadasFuturas.length);

    if (listaEl) {
        if (futuros.length === 0) {
            listaEl.innerHTML =
                '<div class="empty-state">' +
                '<i class="fa-solid fa-calendar-xmark"></i>' +
                (isDono
                    ? '<p>Você ainda não tem aulas agendadas.</p><a href="index.html#agendar" class="btn-primary">Agendar aula</a>'
                    : "<p>Nenhuma aula agendada.</p>") +
                "</div>";
        } else {
            listaEl.innerHTML = futuros.map(function (a) {
                var st = statusAgendamento(a);
                var badge = st === "pendente"
                    ? '<span class="status-badge pendente">Aguardando professor</span>'
                    : '<span class="status-badge confirmada">Confirmada</span>';
                var profObj = getProfessores().find(function (p) { return p.nome === a.professor; });
                var linkProf = profObj
                    ? '<a href="perfil-professor.html?email=' + encodeURIComponent(profObj.email) + '">Prof. ' +
                      escapeHtml(a.professor) + "</a>"
                    : "Prof. " + escapeHtml(a.professor);
                var btn = "";
                if (isDono) {
                    btn = st === "pendente"
                        ? '<button type="button" class="btn-cancel" onclick="cancelarAula(' + a.id + ')">Cancelar pedido</button>'
                        : '<button type="button" class="btn-cancel" onclick="cancelarAula(' + a.id + ')">Cancelar</button>';
                }
                return (
                    '<div class="aula-card">' +
                    '<div class="aula-icon"><i class="fa-solid fa-book-open"></i></div>' +
                    '<div class="aula-info">' +
                    "<strong>" + escapeHtml(a.disciplina) + "</strong>" +
                    "<span>" + linkProf + "</span>" +
                    badge +
                    "</div>" +
                    '<div class="aula-meta">' +
                    '<span><i class="fa-solid fa-calendar"></i> ' + formatarDataBR(a.data) + "</span>" +
                    '<span><i class="fa-solid fa-clock"></i> ' + a.horario + "</span>" +
                    "</div>" +
                    btn +
                    "</div>"
                );
            }).join("");
        }
    }

    // Formulário editar só para dono
    var editForm = document.getElementById("editPerfilForm");
    if (editForm && isDono) {
        document.getElementById("editNome").value = perfilAluno.nome;
        document.getElementById("editEmail").value = perfilAluno.email;

        editForm.addEventListener("submit", function (e) {
            e.preventDefault();
            var novoNome = document.getElementById("editNome").value.trim();
            var novoEmail = document.getElementById("editEmail").value.trim();
            if (!novoNome || !novoEmail) {
                mostrarToast("Preencha nome e e-mail.");
                return;
            }

            var lista = getAlunos();
            var idx = lista.findIndex(function (a) { return a.email === perfilAluno.email; });
            if (idx !== -1) {
                lista[idx].nome = novoNome;
                lista[idx].email = novoEmail;
                if (perfilAluno.foto) lista[idx].foto = perfilAluno.foto;
                setAlunos(lista);
            }

            perfilAluno.nome = novoNome;
            perfilAluno.email = novoEmail;
            if (logado) {
                logado.nome = novoNome;
                logado.email = novoEmail;
                setUsuarioLogado(logado);
            }

            if (nomeEl) nomeEl.textContent = novoNome;
            if (emailEl) emailEl.textContent = novoEmail;
            aplicarFotoNoAvatar(avatarEl, perfilAluno);
            atualizarUIUsuario();
            mostrarToast("Perfil atualizado!");
            fecharModal("editPerfilModal");
        });
    }
}

function cancelarAula(id) {
    var lista = getAgendamentos().filter(function (a) { return a.id !== id; });
    setAgendamentos(lista);
    mostrarToast("Aula cancelada.");
    initPerfilAluno();
}

function responderSolicitacao(id, novoStatus) {
    var usuario = getUsuarioLogado();
    if (!usuario || usuario.tipo !== "professor") {
        mostrarToast("Apenas o professor pode responder solicitações.");
        return;
    }
    var lista = getAgendamentos();
    var idx = lista.findIndex(function (a) { return a.id === id; });
    if (idx === -1) {
        mostrarToast("Solicitação não encontrada.");
        return;
    }
    if (lista[idx].professor !== usuario.nome) {
        mostrarToast("Esta solicitação não é sua.");
        return;
    }
    lista[idx].status = novoStatus;
    setAgendamentos(lista);
    if (novoStatus === "confirmada") {
        mostrarToast("Aula confirmada! O aluno verá na área dele.");
    } else {
        mostrarToast("Solicitação recusada.");
    }
    initPerfilProfessor();
}

function formatarDataBR(iso) {
    var parts = iso.split("-");
    if (parts.length !== 3) return iso;
    return parts[2] + "/" + parts[1] + "/" + parts[0];
}

/* ---------- Página de perfil do PROFESSOR ---------- */

function initPerfilProfessor() {
    atualizarUIUsuario();

    var logado = getUsuarioLogado();
    var emailParam = getQueryParam("email");
    var profs = getProfessores();

    // Perfil a exibir: param ou o próprio professor logado
    var perfilProf = null;
    var isDono = false;

    if (emailParam) {
        perfilProf = profs.find(function (p) {
            return p.email.toLowerCase() === emailParam.toLowerCase();
        });
        if (!perfilProf) {
            mostrarToast("Professor não encontrado.");
            setTimeout(function () { window.location.href = "index.html#professores"; }, 1200);
            return;
        }
        isDono = !!(logado && logado.tipo === "professor" &&
            logado.email.toLowerCase() === perfilProf.email.toLowerCase());
    } else {
        // Sem param: exige login como professor (meu perfil)
        var usuario = exigirLogin(["professor"]);
        if (!usuario) return;
        perfilProf = profs.find(function (p) { return p.email === usuario.email; });
        if (!perfilProf) {
            perfilProf = {
                id: usuario.id,
                nome: usuario.nome,
                email: usuario.email,
                disciplina: usuario.disciplina,
                bio: usuario.bio || "",
                foto: usuario.foto || null,
                tipo: "professor"
            };
        }
        isDono = true;
        // sincroniza dados
        if (perfilProf) {
            usuario.disciplina = perfilProf.disciplina;
            usuario.bio = perfilProf.bio || "";
            usuario.nome = perfilProf.nome;
            if (perfilProf.foto) usuario.foto = perfilProf.foto;
            setUsuarioLogado(usuario);
        }
    }

    var nomeEl = document.getElementById("perfilNome");
    var emailEl = document.getElementById("perfilEmail");
    var discEl = document.getElementById("perfilDisciplina");
    var bioEl = document.getElementById("perfilBio");
    var avatarEl = document.getElementById("perfilAvatarLetter");
    var totalEl = document.getElementById("statTotal");
    var proximasEl = document.getElementById("statProximas");
    var alunosEl = document.getElementById("statAlunos");
    var listaEl = document.getElementById("minhasAulas");
    var btnEditar = document.querySelector('.perfil-header .btn-primary');
    var uploadBox = document.querySelector(".materiais-upload-box");
    var secaoSol = document.getElementById("secao-solicitacoes");
    var secaoAgenda = listaEl ? listaEl.closest(".perfil-section") : null;

    if (nomeEl) nomeEl.textContent = perfilProf.nome;
    if (emailEl) emailEl.textContent = perfilProf.email;
    if (discEl) discEl.textContent = perfilProf.disciplina || "—";
    if (bioEl) bioEl.textContent = perfilProf.bio || "Nenhuma bio definida.";
    aplicarFotoNoAvatar(avatarEl, perfilProf);

    // Avaliação média no header
    var av = mediaAvaliacoes(perfilProf.email);
    var ratingHeader = document.getElementById("perfilRating");
    if (ratingHeader) {
        var est = "★".repeat(Math.round(av.media)) + "☆".repeat(5 - Math.round(av.media));
        ratingHeader.innerHTML = est + ' <small>' + av.media.toFixed(1) +
            (av.total ? ' · ' + av.total + ' avaliação' + (av.total !== 1 ? 'ões' : '') : ' · sem avaliações') +
            '</small>';
    }

    // Banner
    aplicarBannerNoPerfil(perfilProf);

    // Disponibilidade
    setupDisponibilidadeUI(perfilProf, isDono);

    // Controles só do dono
    if (!isDono) {
        if (btnEditar) btnEditar.style.display = "none";
        if (uploadBox) uploadBox.style.display = "none";
        if (secaoSol) secaoSol.style.display = "none";
        if (secaoAgenda) secaoAgenda.style.display = "none";
        var fotoBtn = document.querySelector(".btn-change-photo");
        if (fotoBtn) fotoBtn.style.display = "none";
        var fotoHint = document.querySelector(".perfil-foto-hint");
        if (fotoHint) fotoHint.style.display = "none";
        if (avatarEl) {
            avatarEl.style.cursor = "default";
            avatarEl.title = "";
        }
        var bannerAct = document.getElementById("bannerActions");
        if (bannerAct) bannerAct.style.display = "none";
    } else {
        var bannerAct = document.getElementById("bannerActions");
        if (bannerAct) bannerAct.style.display = "flex";
        setupBannerUpload(perfilProf);
        // Troca de foto
        var fotoInput = document.getElementById("fotoInputProf");
        setupFotoPerfil(avatarEl, fotoInput, function (dataUrl) {
            var lista = getProfessores();
            if (!localStorage.getItem("professores")) lista = getProfessores().slice();
            var idx = lista.findIndex(function (p) { return p.email === perfilProf.email; });
            if (idx !== -1) {
                lista[idx].foto = dataUrl;
                setProfessores(lista);
            } else {
                lista.push({
                    id: perfilProf.id || Date.now(),
                    nome: perfilProf.nome,
                    email: perfilProf.email,
                    disciplina: perfilProf.disciplina,
                    tipo: "professor",
                    bio: perfilProf.bio || "",
                    foto: dataUrl,
                    bannerCor: perfilProf.bannerCor || 1,
                    disponibilidade: perfilProf.disponibilidade || DISP_PADRAO
                });
                setProfessores(lista);
            }
            perfilProf.foto = dataUrl;
            if (logado) {
                logado.foto = dataUrl;
                setUsuarioLogado(logado);
            }
            aplicarFotoNoAvatar(avatarEl, perfilProf);
            mostrarToast("Foto de perfil atualizada!");
        });

        }
    // Materiais (todos podem abrir os links)
    renderizarMateriais(perfilProf.email, isDono);

    var todos = getAgendamentos().filter(function (a) {
        return a.professor === perfilProf.nome || a.professorEmail === perfilProf.email;
    });

    var agora = new Date();
    var pendentes = todos.filter(function (a) {
        return isPendente(a) && new Date(a.data + "T" + a.horario + ":00") >= agora;
    }).sort(function (a, b) {
        return new Date(a.data + "T" + a.horario) - new Date(b.data + "T" + b.horario);
    });

    var confirmadas = todos.filter(isConfirmada);
    var futuros = confirmadas.filter(function (a) {
        return new Date(a.data + "T" + a.horario + ":00") >= agora;
    }).sort(function (a, b) {
        return new Date(a.data + "T" + a.horario) - new Date(b.data + "T" + b.horario);
    });

    var alunosUnicos = {};
    confirmadas.forEach(function (a) { alunosUnicos[a.email] = true; });

    if (totalEl) totalEl.textContent = String(confirmadas.length);
    if (proximasEl) proximasEl.textContent = String(futuros.length);
    if (alunosEl) alunosEl.textContent = String(Object.keys(alunosUnicos).length);

    // Solicitações e agenda só para o dono
    if (isDono) {
        var listaSol = document.getElementById("listaSolicitacoes");
        if (listaSol) {
            if (pendentes.length === 0) {
                listaSol.innerHTML =
                    '<div class="empty-state">' +
                    '<i class="fa-solid fa-inbox"></i>' +
                    "<p>Nenhuma solicitação pendente no momento.</p>" +
                    "</div>";
            } else {
                listaSol.innerHTML = pendentes.map(function (a) {
                    return (
                        '<div class="aula-card solicitacao-card">' +
                        '<div class="aula-icon pending"><i class="fa-solid fa-clock"></i></div>' +
                        "<div class=\"aula-info\">" +
                        "<strong>" + escapeHtml(a.disciplina) + "</strong>" +
                        '<span>Aluno: <a href="perfil-aluno.html?email=' + encodeURIComponent(a.email) + '">' +
                        escapeHtml(a.nome) + "</a></span>" +
                        "<small>" + escapeHtml(a.email) + "</small>" +
                        (a.anoEscolaridade ? "<small><i class=\"fa-solid fa-graduation-cap\"></i> " + escapeHtml(a.anoEscolaridade) + "</small>" : "") +
                        '<span class="status-badge pendente">Pendente</span>' +
                        "</div>" +
                        '<div class="aula-meta">' +
                        "<span><i class=\"fa-solid fa-calendar\"></i> " + formatarDataBR(a.data) + "</span>" +
                        "<span><i class=\"fa-solid fa-clock\"></i> " + a.horario + "</span>" +
                        "</div>" +
                        '<div class="solicitacao-actions">' +
                        '<button type="button" class="btn-accept" onclick="responderSolicitacao(' + a.id + ', \'confirmada\')">Aceitar</button>' +
                        '<button type="button" class="btn-reject" onclick="responderSolicitacao(' + a.id + ', \'recusada\')">Recusar</button>' +
                        "</div>" +
                        "</div>"
                    );
                }).join("");
            }
        }

        if (listaEl) {
            if (futuros.length === 0) {
                listaEl.innerHTML =
                    '<div class="empty-state">' +
                    '<i class="fa-solid fa-calendar-xmark"></i>' +
                    "<p>Nenhuma aula confirmada com você ainda.</p>" +
                    "</div>";
            } else {
                listaEl.innerHTML = futuros.map(function (a) {
                    return (
                        '<div class="aula-card">' +
                        '<div class="aula-icon teacher"><i class="fa-solid fa-user-graduate"></i></div>' +
                        "<div class=\"aula-info\">" +
                        "<strong>" + escapeHtml(a.disciplina) + "</strong>" +
                        '<span>Aluno: <a href="perfil-aluno.html?email=' + encodeURIComponent(a.email) + '">' +
                        escapeHtml(a.nome) + "</a></span>" +
                        "<small>" + escapeHtml(a.email) + "</small>" +
                        (a.anoEscolaridade ? "<small><i class=\"fa-solid fa-graduation-cap\"></i> " + escapeHtml(a.anoEscolaridade) + "</small>" : "") +
                        '<span class="status-badge confirmada">Confirmada</span>' +
                        "</div>" +
                        '<div class="aula-meta">' +
                        "<span><i class=\"fa-solid fa-calendar\"></i> " + formatarDataBR(a.data) + "</span>" +
                        "<span><i class=\"fa-solid fa-clock\"></i> " + a.horario + "</span>" +
                        "</div>" +
                        "</div>"
                    );
                }).join("");
            }
        }

        // Formulário editar
        var editForm = document.getElementById("editPerfilForm");
        if (editForm) {
            document.getElementById("editNome").value = perfilProf.nome;
            document.getElementById("editEmail").value = perfilProf.email;
            document.getElementById("editDisciplina").value = perfilProf.disciplina || "";
            document.getElementById("editBio").value = perfilProf.bio || "";

            editForm.addEventListener("submit", function (e) {
                e.preventDefault();
                var novoNome = document.getElementById("editNome").value.trim();
                var novoEmail = document.getElementById("editEmail").value.trim();
                var novaDisc = document.getElementById("editDisciplina").value.trim();
                var novaBio = document.getElementById("editBio").value.trim();

                if (!novoNome || !novoEmail || !novaDisc) {
                    mostrarToast("Preencha nome, e-mail e disciplina.");
                    return;
                }

                var lista = getProfessores();
                if (!localStorage.getItem("professores")) {
                    lista = getProfessores().slice();
                }
                var idx = lista.findIndex(function (p) { return p.email === perfilProf.email; });
                if (idx !== -1) {
                    lista[idx].nome = novoNome;
                    lista[idx].email = novoEmail;
                    lista[idx].disciplina = novaDisc;
                    lista[idx].bio = novaBio;
                    if (perfilProf.foto) lista[idx].foto = perfilProf.foto;
                } else {
                    lista.push({
                        id: perfilProf.id || Date.now(),
                        nome: novoNome,
                        email: novoEmail,
                        disciplina: novaDisc,
                        tipo: "professor",
                        bio: novaBio,
                        foto: perfilProf.foto || null
                    });
                }
                setProfessores(lista);

                if (logado) {
                    logado.nome = novoNome;
                    logado.email = novoEmail;
                    logado.disciplina = novaDisc;
                    logado.bio = novaBio;
                    setUsuarioLogado(logado);
                }
                perfilProf.nome = novoNome;
                perfilProf.email = novoEmail;
                perfilProf.disciplina = novaDisc;
                perfilProf.bio = novaBio;

                if (nomeEl) nomeEl.textContent = novoNome;
                if (emailEl) emailEl.textContent = novoEmail;
                if (discEl) discEl.textContent = novaDisc;
                if (bioEl) bioEl.textContent = novaBio || "Nenhuma bio definida.";
                aplicarFotoNoAvatar(avatarEl, perfilProf);
                atualizarUIUsuario();
                mostrarToast("Perfil atualizado!");
                fecharModal("editPerfilModal");
            });
        }
    }

    // Avaliações e chat
    renderizarAvaliacoes(perfilProf.email, logado);
    renderizarChatProfessor(perfilProf, logado, isDono);
}

function renderizarMateriais(email, isDono) {
    var listaEl = document.getElementById("listaMateriais");
    if (!listaEl) return;
    var mats = getMateriaisProfessor(email);
    if (mats.length === 0) {
        listaEl.innerHTML =
            '<div class="empty-state materiais-empty">' +
            '<i class="fa-solid fa-link"></i>' +
            "<p>Nenhum link anexado ainda.</p>" +
            "</div>";
        return;
    }
    listaEl.innerHTML = mats.map(function (m) {
        var url = m.url || m.dataUrl || "#";
        var titulo = m.nome || m.titulo || "Link";
        return (
            '<div class="material-card">' +
            '<div class="material-icon"><i class="fa-solid fa-link"></i></div>' +
            '<div class="material-info">' +
            "<strong>" + escapeHtml(titulo) + "</strong>" +
            '<span class="material-url-preview">' + escapeHtml(url.length > 50 ? url.slice(0, 50) + "…" : url) + "</span>" +
            "</div>" +
            '<div class="material-actions">' +
            '<a class="btn-download" href="' + escapeHtml(url) + '" target="_blank" rel="noopener noreferrer" title="Abrir link"><i class="fa-solid fa-external-link-alt"></i></a>' +
            (isDono
                ? '<button type="button" class="btn-remove-mat" onclick="removerMaterial(\'' + email.replace(/'/g, "\\'") + "', " + m.id + ')" title="Remover"><i class="fa-solid fa-trash"></i></button>'
                : "") +
            "</div>" +
            "</div>"
        );
    }).join("");
}

function removerMaterial(email, id) {
    var mats = getMateriaisProfessor(email).filter(function (m) { return m.id !== id; });
    setMateriaisProfessor(email, mats);
    renderizarMateriais(email, true);
    mostrarToast("Link removido.");
}

function anexarLinkMaterial() {
    var logado = getUsuarioLogado();
    if (!logado || logado.tipo !== "professor") {
        mostrarToast("Somente o professor pode anexar links.");
        return;
    }
    var tituloEl = document.getElementById("materialLinkTitulo");
    var urlEl = document.getElementById("materialLinkUrl");
    if (!tituloEl || !urlEl) return;
    var titulo = (tituloEl.value || "").trim();
    var url = (urlEl.value || "").trim();
    if (!titulo) {
        mostrarToast("Informe um título para o material.");
        return;
    }
    if (!url) {
        mostrarToast("Informe o link do material.");
        return;
    }
    // Normaliza URL se não tiver protocolo
    if (!/^https?:\/\//i.test(url)) {
        url = "https://" + url;
    }
    try {
        new URL(url);
    } catch (e) {
        mostrarToast("Link inválido. Verifique a URL.");
        return;
    }
    var mats = getMateriaisProfessor(logado.email);
    mats.push({
        id: Date.now(),
        nome: titulo,
        titulo: titulo,
        url: url,
        tipo: "link",
        dataUpload: new Date().toISOString()
    });
    setMateriaisProfessor(logado.email, mats);
    renderizarMateriais(logado.email, true);
    tituloEl.value = "";
    urlEl.value = "";
    mostrarToast("Link anexado com sucesso!");
}

function renderizarAvaliacoes(profEmail, logado) {
    var secao = document.getElementById("secao-avaliacoes");
    if (!secao) return;
    secao.style.display = "block";

    var listaEl = document.getElementById("listaAvaliacoes");
    var formWrap = document.getElementById("formAvaliacaoWrap");
    var av = mediaAvaliacoes(profEmail);
    var lista = getAvaliacoes(profEmail);

    var mediaEl = document.getElementById("avaliacaoMedia");
    if (mediaEl) {
        mediaEl.innerHTML = "<strong>" + av.media.toFixed(1) + "</strong> / 5 · " +
            av.total + " avaliação" + (av.total !== 1 ? "ões" : "");
    }

    if (listaEl) {
        if (!lista.length) {
            listaEl.innerHTML =
                '<div class="empty-state"><i class="fa-solid fa-star"></i><p>Ainda não há avaliações.</p></div>';
        } else {
            listaEl.innerHTML = lista.slice().reverse().map(function (a) {
                var est = "★".repeat(a.nota) + "☆".repeat(5 - a.nota);
                return (
                    '<div class="avaliacao-card">' +
                    '<div class="avaliacao-header">' +
                    '<span class="avaliacao-estrelas">' + est + "</span>" +
                    '<span class="avaliacao-autor">' + escapeHtml(a.alunoNome || a.alunoEmail) + "</span>" +
                    '<span class="avaliacao-data">' + (a.data ? formatarDataBR(a.data.slice(0, 10)) : "") + "</span>" +
                    "</div>" +
                    (a.comentario ? '<p class="avaliacao-comentario">' + escapeHtml(a.comentario) + "</p>" : "") +
                    "</div>"
                );
            }).join("");
        }
    }

    if (formWrap) {
        var podeAvaliar = logado && logado.tipo === "aluno" &&
            alunoTeveAulaCom(profEmail, logado.email) &&
            !alunoJaAvaliou(profEmail, logado.email);
        if (podeAvaliar) {
            formWrap.style.display = "block";
            formWrap.innerHTML =
                '<form id="formAvaliacao" class="form-avaliacao">' +
                "<label>Sua nota</label>" +
                '<div class="stars-input" id="starsInput">' +
                [1, 2, 3, 4, 5].map(function (n) {
                    return '<button type="button" class="star-btn" data-nota="' + n + '">☆</button>';
                }).join("") +
                "</div>" +
                '<input type="hidden" id="avaliacaoNota" value="0">' +
                '<label for="avaliacaoComentario">Comentário (opcional)</label>' +
                '<textarea id="avaliacaoComentario" rows="2" placeholder="Como foi a aula?"></textarea>' +
                '<button type="submit" class="btn-primary">Enviar avaliação</button>' +
                "</form>";
            var notaSel = 0;
            formWrap.querySelectorAll(".star-btn").forEach(function (btn) {
                btn.addEventListener("click", function () {
                    notaSel = Number(btn.getAttribute("data-nota"));
                    document.getElementById("avaliacaoNota").value = notaSel;
                    formWrap.querySelectorAll(".star-btn").forEach(function (b, i) {
                        b.textContent = i < notaSel ? "★" : "☆";
                        b.classList.toggle("active", i < notaSel);
                    });
                });
            });
            document.getElementById("formAvaliacao").addEventListener("submit", function (e) {
                e.preventDefault();
                var nota = Number(document.getElementById("avaliacaoNota").value);
                if (!nota || nota < 1 || nota > 5) {
                    mostrarToast("Selecione uma nota de 1 a 5.");
                    return;
                }
                var comentario = (document.getElementById("avaliacaoComentario").value || "").trim();
                var listaAv = getAvaliacoes(profEmail);
                listaAv.push({
                    alunoEmail: logado.email,
                    alunoNome: logado.nome,
                    nota: nota,
                    comentario: comentario,
                    data: new Date().toISOString()
                });
                setAvaliacoes(profEmail, listaAv);
                mostrarToast("Avaliação enviada! Obrigado.");
                renderizarAvaliacoes(profEmail, logado);
            });
        } else if (logado && logado.tipo === "aluno" && alunoJaAvaliou(profEmail, logado.email)) {
            formWrap.style.display = "block";
            formWrap.innerHTML = '<p class="avaliacao-ja-feita"><i class="fa-solid fa-check"></i> Você já avaliou este professor.</p>';
        } else if (logado && logado.tipo === "aluno") {
            formWrap.style.display = "block";
            formWrap.innerHTML = '<p class="avaliacao-hint">Agende e confirme uma aula com este professor para poder avaliá-lo.</p>';
        } else {
            formWrap.style.display = "none";
        }
    }
}

function renderizarChatProfessor(perfilProf, logado, isDono) {
    var secao = document.getElementById("secao-chat");
    if (!secao) return;

    // Sem e-mail logado: não exibe o bate-papo no perfil do professor
    if (!logado || !logado.email) {
        secao.style.display = "none";
        return;
    }

    secao.style.display = "block";

    var container = document.getElementById("chatContainer");
    if (!container) return;

    if (logado && logado.tipo === "aluno") {
        var temAula = getAgendamentos().some(function (a) {
            return a.email === logado.email &&
                (a.professor === perfilProf.nome || a.professorEmail === perfilProf.email) &&
                statusAgendamento(a) !== "recusada";
        });
        if (!temAula) {
            container.innerHTML =
                '<div class="empty-state"><i class="fa-solid fa-comments"></i>' +
                "<p>Agende uma aula com este professor para iniciar o bate-papo.</p></div>";
            return;
        }
        renderizarConversa(container, perfilProf.email, logado.email, "aluno", perfilProf.nome);
        return;
    }

    if (isDono && logado && logado.tipo === "professor") {
        var conversas = listarConversasProfessor(perfilProf.email);
        if (!conversas.length) {
            container.innerHTML =
                '<div class="empty-state"><i class="fa-solid fa-comments"></i>' +
                "<p>Nenhuma conversa ainda. Quando um aluno agendar, o chat aparecerá aqui.</p></div>";
            return;
        }
        var alunoParam = getQueryParam("chat");
        var html = '<div class="chat-layout">';
        html += '<div class="chat-sidebar"><h4>Conversas</h4><ul class="chat-lista-alunos">';
        conversas.forEach(function (c) {
            var alunos = getAlunos();
            var al = alunos.find(function (x) { return x.email === c.alunoEmail; });
            var nome = (al && al.nome) || c.nomeAluno || c.alunoEmail;
            var active = alunoParam === c.alunoEmail ? " active" : "";
            html += '<li class="chat-aluno-item' + active + '">' +
                '<a href="perfil-professor.html?email=' + encodeURIComponent(perfilProf.email) +
                "&chat=" + encodeURIComponent(c.alunoEmail) + '">' +
                escapeHtml(nome) +
                (c.ultima ? "<small>" + escapeHtml(c.ultima.texto.slice(0, 40)) + "</small>" : "") +
                "</a></li>";
        });
        html += '</ul></div><div class="chat-main" id="chatMain"></div></div>';
        container.innerHTML = html;
        if (alunoParam) {
            renderizarConversa(document.getElementById("chatMain"), perfilProf.email, alunoParam, "professor", null);
        } else {
            document.getElementById("chatMain").innerHTML =
                '<div class="empty-state"><p>Selecione um aluno para conversar.</p></div>';
        }
        return;
    }

    container.innerHTML =
        '<div class="empty-state"><i class="fa-solid fa-lock"></i>' +
        "<p>Faça login como aluno (com aula agendada) ou como o professor para usar o bate-papo.</p></div>";
}

function renderizarConversa(container, profEmail, alunoEmail, meuTipo, nomeOutro) {
    if (!container) return;
    var msgs = getChat(profEmail, alunoEmail);
    var alunos = getAlunos();
    var al = alunos.find(function (x) { return x.email === alunoEmail; });
    var titulo = meuTipo === "aluno"
        ? ("Chat com " + (nomeOutro || "professor"))
        : ("Chat com " + ((al && al.nome) || alunoEmail));

    var html = '<div class="chat-box">';
    html += '<div class="chat-titulo"><i class="fa-solid fa-comments"></i> ' + escapeHtml(titulo) + "</div>";
    html += '<div class="chat-mensagens" id="chatMensagens">';
    if (!msgs.length) {
        html += '<p class="chat-vazio">Nenhuma mensagem ainda. Diga olá!</p>';
    } else {
        msgs.forEach(function (m) {
            var cls = m.de === meuTipo ? "msg-minha" : "msg-outra";
            var hora = "";
            try {
                var d = new Date(m.data);
                hora = d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
            } catch (e) {}
            html += '<div class="chat-msg ' + cls + '">' +
                "<p>" + escapeHtml(m.texto) + "</p>" +
                '<span class="chat-hora">' + hora + "</span></div>";
        });
    }
    html += "</div>";
    html += '<form class="chat-form" id="chatForm">' +
        '<input type="text" id="chatInput" placeholder="Digite sua mensagem..." autocomplete="off" required>' +
        '<button type="submit" class="btn-primary"><i class="fa-solid fa-paper-plane"></i></button>' +
        "</form></div>";
    container.innerHTML = html;

    var msgsEl = document.getElementById("chatMensagens");
    if (msgsEl) msgsEl.scrollTop = msgsEl.scrollHeight;

    document.getElementById("chatForm").addEventListener("submit", function (e) {
        e.preventDefault();
        var input = document.getElementById("chatInput");
        var texto = (input.value || "").trim();
        if (!texto) return;
        enviarMensagemChat(profEmail, alunoEmail, meuTipo, texto);
        input.value = "";
        renderizarConversa(container, profEmail, alunoEmail, meuTipo, nomeOutro);
    });
}

function escapeHtml(str) {
    if (!str) return "";
    return String(str)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
}

/* ---------- Banner do professor ---------- */

function aplicarBannerNoPerfil(prof) {
    var banner = document.getElementById("perfilBanner");
    if (!banner || !prof) return;
    banner.className = "perfil-banner";
    banner.style.backgroundImage = "";
    if (prof.bannerImg) {
        banner.classList.add("has-image");
        banner.style.backgroundImage = "url(" + prof.bannerImg + ")";
        var btnRem = document.getElementById("btnRemoverBanner");
        if (btnRem) btnRem.style.display = "inline-flex";
    } else {
        var cor = prof.bannerCor || 1;
        banner.classList.add("banner-preset-" + cor);
        var btnRem = document.getElementById("btnRemoverBanner");
        if (btnRem) btnRem.style.display = "none";
    }
}

function salvarCampoProfessor(email, campos) {
    var lista = getProfessores();
    if (!localStorage.getItem("professores")) lista = getProfessores().slice();
    var idx = lista.findIndex(function (p) { return p.email === email; });
    if (idx !== -1) {
        Object.keys(campos).forEach(function (k) { lista[idx][k] = campos[k]; });
    } else {
        var base = Object.assign({ id: Date.now(), email: email, tipo: "professor" }, campos);
        lista.push(base);
    }
    setProfessores(lista);
    return lista[idx !== -1 ? idx : lista.length - 1];
}

function setupBannerUpload(perfilProf) {
    var input = document.getElementById("bannerInput");
    if (!input) return;
    input.addEventListener("change", function () {
        var file = input.files && input.files[0];
        if (!file) return;
        if (!file.type || file.type.indexOf("image/") !== 0) {
            mostrarToast("Selecione uma imagem.");
            input.value = "";
            return;
        }
        lerArquivoComoDataURL(file, 900 * 1024, function (dataUrl) {
            perfilProf.bannerImg = dataUrl;
            perfilProf.bannerCor = null;
            salvarCampoProfessor(perfilProf.email, { bannerImg: dataUrl, bannerCor: null });
            aplicarBannerNoPerfil(perfilProf);
            mostrarToast("Banner atualizado!");
            input.value = "";
        });
    });
}

function abrirSeletorCoresBanner() {
    document.getElementById("bannerCoresModal").classList.add("active");
}

function aplicarCorBanner(preset) {
    var page = document.body.getAttribute("data-page");
    if (page !== "perfil-professor") return;
    var logado = getUsuarioLogado();
    if (!logado || logado.tipo !== "professor") return;
    var lista = getProfessores();
    var prof = lista.find(function (p) { return p.email === logado.email; }) || logado;
    prof.bannerCor = preset;
    prof.bannerImg = null;
    salvarCampoProfessor(prof.email, { bannerCor: preset, bannerImg: null });
    aplicarBannerNoPerfil(prof);
    fecharModal("bannerCoresModal");
    mostrarToast("Cor do banner atualizada!");
}

function removerBanner() {
    var logado = getUsuarioLogado();
    if (!logado || logado.tipo !== "professor") return;
    var lista = getProfessores();
    var prof = lista.find(function (p) { return p.email === logado.email; }) || logado;
    prof.bannerImg = null;
    if (!prof.bannerCor) prof.bannerCor = 1;
    salvarCampoProfessor(prof.email, { bannerImg: null, bannerCor: prof.bannerCor || 1 });
    aplicarBannerNoPerfil(prof);
    mostrarToast("Imagem do banner removida.");
}

/* ---------- Disponibilidade de horários ---------- */

function setupDisponibilidadeUI(perfilProf, isDono) {
    var editor = document.getElementById("dispEditor");
    var resumo = document.getElementById("dispResumoVisitante");
    var desc = document.getElementById("dispDescricao");
    if (!perfilProf) return;

    var disp = perfilProf.disponibilidade || DISP_PADRAO;

    if (isDono) {
        if (desc) desc.textContent = "Selecione os dias e horários em que você pode dar aulas. Os alunos só poderão agendar nesses slots.";
        if (editor) editor.style.display = "block";
        if (resumo) resumo.style.display = "none";
        // marcar botões
        document.querySelectorAll("#dispDias .disp-dia-btn").forEach(function (btn) {
            var d = parseInt(btn.getAttribute("data-dia"), 10);
            btn.classList.toggle("active", (disp.dias || []).indexOf(d) !== -1);
            btn.onclick = function () { btn.classList.toggle("active"); };
        });
        document.querySelectorAll("#dispHorarios .disp-hora-btn").forEach(function (btn) {
            var h = btn.getAttribute("data-hora");
            btn.classList.toggle("active", (disp.horarios || []).indexOf(h) !== -1);
            btn.onclick = function () { btn.classList.toggle("active"); };
        });
    } else {
        if (desc) desc.textContent = "Dias e horários em que este professor pode dar aulas.";
        if (editor) editor.style.display = "none";
        if (resumo) {
            resumo.style.display = "flex";
            var html = "";
            (disp.dias || []).forEach(function (d) {
                html += '<span class="chip dia">' + (DIAS_NOMES[d] || d) + '</span>';
            });
            (disp.horarios || []).forEach(function (h) {
                html += '<span class="chip">' + h + '</span>';
            });
            if (!html) html = '<span class="disp-empty">Nenhum horário definido.</span>';
            resumo.innerHTML = html;
        }
    }
}

function salvarDisponibilidade() {
    var logado = getUsuarioLogado();
    if (!logado || logado.tipo !== "professor") {
        mostrarToast("Faça login como professor.");
        return;
    }
    var dias = [];
    document.querySelectorAll("#dispDias .disp-dia-btn.active").forEach(function (btn) {
        dias.push(parseInt(btn.getAttribute("data-dia"), 10));
    });
    var horarios = [];
    document.querySelectorAll("#dispHorarios .disp-hora-btn.active").forEach(function (btn) {
        horarios.push(btn.getAttribute("data-hora"));
    });
    if (dias.length === 0 || horarios.length === 0) {
        mostrarToast("Selecione ao menos um dia e um horário.");
        return;
    }
    dias.sort(function (a, b) { return a - b; });
    horarios.sort();
    var disp = { dias: dias, horarios: horarios };
    salvarCampoProfessor(logado.email, { disponibilidade: disp });
    logado.disponibilidade = disp;
    setUsuarioLogado(logado);
    mostrarToast("Horários disponíveis salvos!");
}

function getDisponibilidadeProfessor(nomeOuEmail) {
    var proffs = getProfessores();
    var p = proffs.find(function (x) {
        return x.nome === nomeOuEmail || x.email === nomeOuEmail;
    });
    return (p && p.disponibilidade) ? p.disponibilidade : DISP_PADRAO;
}

function atualizarHorariosDisponiveis() {
    var teacherSel = document.getElementById("teacher");
    var dateInput = document.getElementById("date");
    var timeSel = document.getElementById("time");
    if (!teacherSel || !timeSel) return;

    var professor = teacherSel.value;
    var data = dateInput ? dateInput.value : "";
    var valorAtual = timeSel.value;

    var todosHorarios = ["08:00","09:00","10:00","11:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00"];
    var disponiveis = todosHorarios;

    if (professor) {
        var disp = getDisponibilidadeProfessor(professor);
        disponiveis = disp.horarios || todosHorarios;

        if (data) {
            var partes = data.split("-").map(Number);
            var diaSemana = new Date(partes[0], partes[1] - 1, partes[2]).getDay();
            if ((disp.dias || []).indexOf(diaSemana) === -1) {
                disponiveis = [];
            }
        }
    }

    timeSel.innerHTML = '<option value="">Horário</option>';
    if (disponiveis.length === 0 && professor && data) {
        var opt = document.createElement("option");
        opt.value = "";
        opt.textContent = "Professor indisponível neste dia";
        opt.disabled = true;
        timeSel.appendChild(opt);
    } else {
        disponiveis.forEach(function (h) {
            var opt = document.createElement("option");
            opt.value = h;
            opt.textContent = h;
            timeSel.appendChild(opt);
        });
        if (valorAtual && disponiveis.indexOf(valorAtual) !== -1) {
            timeSel.value = valorAtual;
        }
    }
}

/* ---------- Boot ---------- */

document.addEventListener("DOMContentLoaded", function () {
    var page = document.body.getAttribute("data-page") || "home";

    atualizarUIUsuario();

    if (page === "home") {
        initHomeForms();
        atualizarSelectDisciplinas();
        atualizarSelectProfessores();
        renderizarProfessores();
        renderizarCalendario();
    } else if (page === "perfil-aluno") {
        initPerfilAluno();
    } else if (page === "perfil-professor") {
        initPerfilProfessor();
    }
});
